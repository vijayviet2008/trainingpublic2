<?php

namespace Drupal\my_training\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

class MyTrainingConfigForm extends ConfigFormBase {

  /**
   * Get form Id to add setting for config.
   */
  public function getFormId() {
    return 'mytraining_admin_settings';
  }

  /**
   * Get form rout to add setting for config.
   */
  protected function getEditableConfigNames() {
    return [
      'training.settings',
    ];
  }

  /**
   * Add filed to form for setting of config.
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form = parent::buildForm($form, $form_state);
    $config = \Drupal::config('training.settings');
    //kint($config);    
    // username.
    $form['user'] = [
      '#type' => 'textfield',
      '#title' => $this->t('User name'),
      '#default_value' => $config->get('mytraining.page.user'),
    ];
    // email.
    $form['email'] = [
      '#type' => 'email',
      '#title' => $this->t('E-mail'),
      '#default_value' => $config->get('mytraining.page.email'),
    ];
    
    return parent::buildForm($form, $form_state);
  }

  /**
   * Submit form to add setting for config.
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Retrieve the configuration.
    $this->configFactory->getEditable('training.settings')
      // Set the submitted configuration setting.
      ->set('mytraining.page.user', $form_state->getValue('user'))
      ->set('mytraining.page.email', $form_state->getValue('email'))
      ->save();

    parent::submitForm($form, $form_state);
  }

}