<?php

namespace Drupal\my_training\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Implements Training form API.
 */
class MyTrainingForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

   $options = [
      '1' => $this->t('Rame'),
      '2' => $this->t('Shayam')
    ];
    $form['training_descrip'] = [
      '#type' => 'item',
      '#markup' => $this->t('Using form API for diffrent field type.'),
    ];

    // Textfield.
    $form['name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Name'),
      '#size' => 60,
      '#maxlength' => 128,
      '#required' => TRUE,
    ];
     // Textarea.
     $form['text_area'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Text'),
      '#description' => $this->t('Textarea'),
      '#required' => TRUE,
    ];
    // Radios.
    $form['radio_button'] = [
      '#type' => 'radios',
      '#title' => $this->t('Status'),
      '#options' => $options,
    ];

    // Search.
    $form['search'] = [
      '#type' => 'search',
      '#title' => $this->t('Search'),
    ];
    // CheckBoxes.
    $form['mytraing_checkbox'] = [
      '#type' => 'checkboxes',
      '#options' => $options,
      '#title' => $this->t('Checkbox'),
      '#description' => 'Checkboxes, #type = checkboxes',
    ];
    // Date.
    $form['dob'] = [
      '#type' => 'date',
      '#title' => $this->t('DOB'),
      '#description' => 'Date, #type = date',
    ];

    // Date-time.
    $form['event_date'] = [
      '#type' => 'datetime',
      '#title' => 'Event Time',
      '#date_increment' => 1,
      '#date_timezone' => drupal_get_user_timezone(),
      '#default_value' => drupal_get_user_timezone(),
    ];

    // URL.
    $form['facebook_url'] = [
      '#type' => 'url',
      '#title' => $this->t('Facebook URL'),
      '#maxlength' => 255,
      '#size' => 30,
    ];

    // Email.
    $form['email'] = [
      '#type' => 'email',
      '#title' => $this->t('Your Email'),
      '#required' => TRUE,
    ];

    // Number.
    $form['Oreder_id'] = [
      '#type' => 'number',
      '#title' => $this->t('Order Id'),
    ];

    // Password.
    $form['password'] = [
      '#type' => 'password',
      '#title' => $this->t('Enter Password'),
    ];

    // Password Confirm.
    $form['password_confirm'] = [
      '#type' => 'password_confirm',
      '#title' => $this->t('Confirm Password'),
    ];
    
     // File.
     $form['file'] = [
      '#type' => 'file',
      '#title' => 'File',
      '#description' => $this->t('File'),
    ];

    // Manage file.
    $form['managed_file'] = [
      '#type' => 'managed_file',
      '#title' => 'Managed file',
      '#description' => $this->t('Manage file'),
    ];
    // Select.
    $form['select_box'] = [
      '#type' => 'select',
      '#title' => $this->t('My select box'),
      '#options' => $options,
      '#empty_option' => $this->t('-select-'),
      '#description' => $this->t('Select'),
    ];

    // Multiple values option elements.
    $form['select_multiple'] = [
      '#type' => 'select',
      '#title' => 'Select (multiple)',
      '#multiple' => TRUE,
      '#options' => $options,
      '#default_value' => ['sat'],
      '#description' => 'Select Multiple',
    ];

    // Tel.
    $form['phone'] = [
      '#type' => 'tel',
      '#title' => $this->t('Phone'),
      '#description' => $this->t('Tel, #type = tel'),
      '#required' => TRUE,
    ];
    // Text format.
    $form['text_format'] = [
      '#type' => 'text_format',
      '#title' => 'Text format',
      '#format' => 'plain_text',
      '#expected_value' => [
        'value' => 'Text value',
        'format' => 'plain_text',
      ],
      '#textformat_value' => [
        'value' => 'Testvalue',
        'format' => 'filtered_html',
      ],
      '#description' => $this->t('Text format'),
    ];

    $form['actions'] = [
      '#type' => 'actions',
    ];

    // Add a submit button that handles the submission of the form.
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Submit'),
      '#description' => $this->t('Submit, #type = submit'),
    ];

    // Add a reset button that handles the submission of the form.
    $form['actions']['reset'] = [
      '#type' => 'button',
      '#button_type' => 'reset',
      '#value' => $this->t('Reset'),
      '#description' => $this->t('Submit, #type = button, #button_type = reset, #attributes = this.form.reset();return false'),
      '#attributes' => [
        'onclick' => 'this.form.reset(); return false;',
      ],
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'mytraining_form_api';
  }

  /**
   * Implements form validation.
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    $name = $form_state->getValue('name');
    $text_area = $form_state->getValue('text_area');
    $email = $form_state->getValue('email');
    $phone = $form_state->getValue('phone');
    if (empty($name)) {
      $form_state->setErrorByName('name', $this->t('Please enter name.'));
    }
    if (empty($text_area)) {
      $form_state->setErrorByName('text_area', $this->t('Please enter  text area.'));
    }
    if (empty($email)) {
      $form_state->setErrorByName('email', $this->t('Please enter email.'));
    }
    if (empty($phone)) {
      $form_state->setErrorByName('phone', $this->t('Please enter phone.'));
    }
    if (!empty($phone) && !is_numeric($phone)) {
      $form_state->setErrorByName('phone', $this->t('Please enter valid phone.'));
    }
    if (strlen($phone) < 10) {
      // Set an error for the form element with a key of "title".
      $form_state->setErrorByName('phone', $this->t('The phone must be at least 10 digit long.'));
    }
    //ete...
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Find out what was submitted.
    $values = $form_state->getValues();
    $name = $form_state->getValue('name');
    $text_area = $form_state->getValue('text_area');
    $email = $form_state->getValue('email');
    $phone = $form_state->getValue('phone');
    $select_box = $form_state->getValue('select_box');
    $text_format = $form_state->getValue('text_format');

    $password = $form_state->getValue('password');
    $facebook_url = $form_state->getValue('facebook_url');
    $event_date = $form_state->getValue('event_date');
    $dob = $form_state->getValue('dob');
  
    // so on get all field value
    $this->messenger()->addMessage('Form Submitted successfully.');
  }

}
