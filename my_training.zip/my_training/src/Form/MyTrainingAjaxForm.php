<?php

namespace Drupal\my_training\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Implements Training Ajax form API.
 */
class MyTrainingAjaxForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $options = [
      '1' => $this->t('Show Input Field'),
      '2' => $this->t('Show Radio Field')
    ];

    $radio_options = [
      '1' => $this->t('1'),
      '2' => $this->t('2'),
      '3' => $this->t('3'),
      '4' => $this->t('4')
    ];
    $value = $form_state->getValue('select_box');
    // Select.
    $form['select_box'] = [
      '#type' => 'select',
      '#title' => $this->t('Select Fileld Type'),
      '#options' => $options,
      '#empty_option' => $this->t('-select-'),
      '#ajax' => [
        'callback' => '::selectDropdownCallback',
        'wrapper' => 'name-fieldset-container',
      ],
    ];
    $form['name_fieldset_container'] = [
      '#type' => 'container',
      '#attributes' => ['id' => 'name-fieldset-container'],
    ];
    
    if ($value == 1) {
      // Textfield.
      $form['name_fieldset_container']['name'] = [
        '#type' => 'textfield',
        '#title' => $this->t('Name'),
        '#size' => 60,
        '#maxlength' => 128,
      ];
    } 
    if ($value == 2) {
      $form['name_fieldset_container']['age'] = [
        '#type' => 'radios',
        '#title' => $this->t('Age'),
        '#options' => $radio_options,
      ];
    } 
    $form['actions'] = [
      '#type' => 'actions',
    ];

    // Add a submit button that handles the submission of the form.
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Submit'),
      '#description' => $this->t('Submit, #type = submit'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'mytraining_form_api';
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $name = $form_state->getValue('select_box');
    $name = $form_state->getValue('name');
    $this->messenger()->addMessage('Form submitted successfully.');
  }

  /**
   * Handles switching the available regions based on the selected theme.
   */
  public function selectDropdownCallback($form, FormStateInterface $form_state) {
    return $form['name_fieldset_container'];
  }
}
