<?php

namespace Drupal\my_training\controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\user\Entity\User;


class TrainingController extends ControllerBase{

  public function simplePage(){
    $build = [];
    $build['#markup'] = "this is test page";
    return $build;
  }
  public function userDetails($uid){
    $user_info = [];
    if(is_numeric($uid)){
      $user_detail = User::load($uid); 
      if(!empty($user_detail)){
        //kint($user_detail);        
        $user_name = $user_detail->getUsername();            
        $user_email = $user_detail->get('mail')->value;
        $user_info['#markup'] = '<p> User Name :' .$user_name  . '<br><br> Mail Id : '.$user_email.'</p>';
        
      }
      else {
        \Drupal::messenger()->addError(t('User does not exist')); 
        $user_info['#markup'] = 'User does not exist';
      }
    }
    else{
        \Drupal::messenger()->addError(t('Aregument is not valid')); 
        $user_info['#markup'] = 'Aregument is not valid';
    }
    return $user_info;
  }
  public function showConfigValueOnPage(){
    $build = [];
    $config = \Drupal::config('training.settings');
    //kint($config);  
    $user = $config->get('mytraining.page.user'); 
    $email = $config->get('mytraining.page.email'); 
   
    $build['#markup'] = '<p> User Name :' .$user  . '<br><br> Mail Id : '.$email.'</p>';
    return $build;
  }
}