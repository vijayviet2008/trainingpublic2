<?php

interface Calculaterinterface{
  
    public function add();
    public function substract();
    public function multiply();
    public function divide();
}

class Claculater implements Calculaterinterface {
    public $num1 = '';
    public $num2 = '';

    function add(){
        $num1 = $this->num1;
        $num2 = $this->num2;
        if(is_numeric($num1) && is_numeric($num2)){
            return  $num1+$num2;
        }
        else{
         return "Inputs are not valid";
        }
    }
    function substract(){
        $num1 = $this->num1;
        $num2 = $this->num2;
        if(is_numeric($num1) && is_numeric($num2)){
             return $num1-$num2;
        }
        else{
            return "Inputs are not valid";
        }
    }
    function multiply(){
        $num1 = $this->num1;
        $num2 = $this->num2;
        if(is_numeric($num1) && is_numeric($num2)){
            return $num1*$num2;
        }
        else{
             return "Inputs are not valid";
        }
    }
    function divide(){
        $num1 = $this->num1;
        $num2 = $this->num2;
        if(is_numeric($num1) && is_numeric($num2)){
            return $num1/$num2;
        }
        else{
        return "Inputs are not valid";
        }
    }
}

$cal = new Claculater; 
$cal->num1 = 20;
$cal->num2 = 15;

echo "Sum of ".$cal->num1." and ".$cal->num2. " = ". $cal->add(); 

echo "<br><br>";

echo "Substration of ".$cal->num1." and ".$cal->num2. " = ". $cal->substract(); 

echo "<br><br>";

echo "Multiplication of ".$cal->num1." and ".$cal->num2. " = ". $cal->multiply(); 

echo "<br><br>";

echo "Division of ".$cal->num1." and ".$cal->num2. " = ". $cal->divide(); 
