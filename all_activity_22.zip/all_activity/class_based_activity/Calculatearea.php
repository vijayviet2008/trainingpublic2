<?php
interface Calculateareainterface{
  
   
    public function getwidth();
    public function getlenght();
    public function getarea();
}

class Calculatearea implements Calculateareainterface {
    public $lenght = '';
    public $width = '';
    
    function __construct($lenght, $width){
        $this->lenght = $lenght;
        $this->width = $width;        
    }
    
    public function getwidth(){
        echo "Width is ".$this->width;
    }
    public function getlenght(){
        echo "Lenght is ".$this->lenght;
    }
    public function getarea(){
        $area = $this->lenght*$this->width;
        echo "Area of ".$this->lenght ." and ".$this->width ." = ".$area;
    }
    
}

 $cal = new Calculatearea(100, 200); 

 echo  $cal->getwidth(); 

echo "<br><br>";

echo $cal->getlenght(); 

echo "<br><br>";

echo  $cal->getarea(); 
// print_r($cal);

