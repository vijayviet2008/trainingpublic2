<?php

trait pageloadlogger {
public function logger() {
    echo "This is logger on page load";
  }
}

class Pageload {
  use pageloadlogger;
}

$obj = new Pageload();
$obj->logger();