<?php

namespace Drupal\better_exposed_filters\Plugin\better_exposed_filters\pager;

/**
 * Default widget implementation.
 *
 * @BetterExposedFiltersPagerWidget(
 *   id = "default",
 *   label = @Translation("Default"),
 * )
 */
class DefaultWidget extends PagerWidgetBase {

}
