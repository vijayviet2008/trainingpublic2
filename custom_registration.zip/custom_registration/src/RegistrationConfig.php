<?php

namespace Drupal\custom_registration;

use Drupal\Core\Config\ConfigFactoryInterface;

/**
 * RegistrationConfig service.
 */
class RegistrationConfig {

  protected $configFactory;

  /**
   * Constructor to initialize the object.
   */
  public function __construct(ConfigFactoryInterface $config_factory) {
    $this->configFactory = $config_factory;
  }
  

  /**
   * function to save registration data in config.
   */
  public function saveRegistrationConfigData($registrationData) {

    $config = $this->configFactory->getEditable('custom_registration.trainingregistrationconfig');
    if(!empty($config->get('regidata'))){
      $regdata = unserialize($config->get('regidata'));
    }
    //creating registration data array so that multiple data can be save in single variable
    // and at time of edit array index will be work as id 
    $regdata[] = $registrationData;
    //kint($regdata); exit;
    $seriRegistrationData = serialize($regdata);
    $config->set('regidata', $seriRegistrationData);
    $config->save();
  }

  /**
   * function to save registration data in config.
   */
  public function editRegistrationConfigData($registrationData, $id) {

    $config = $this->configFactory->getEditable('custom_registration.trainingregistrationconfig');
    if(!empty($config->get('regidata'))){
      $regdata = unserialize($config->get('regidata'));
    }
    //creating registration data array so that multiple data can be save in single variable
    // and at time of edit array index will be work as id 
  
    $regdata[$id] = $registrationData;

    //kint($regdata); exit;
    $seriRegistrationData = serialize($regdata);
    $config->set('regidata', $seriRegistrationData);
    $config->save();
  }

}
