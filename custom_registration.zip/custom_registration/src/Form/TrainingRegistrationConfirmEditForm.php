<?php

namespace Drupal\custom_registration\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Class TrainingRegistrationConfirmEditForm.
 */
class TrainingRegistrationConfirmEditForm extends ConfigFormBase {

   /**
   * Drupal\Core\Config\ConfigManagerInterface definition.
   *
   * @var \Drupal\Core\Config\ConfigManagerInterface
   */
  protected $configManager;
  private $regConfig;
  /**
   * Constructor to initialize the object.
   */
  public function __construct($configManager, $regConfig) {
    $this->configManager = $configManager;
    $this->regConfig = $regConfig;
  }
  
  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.manager'),
      $container->get('custom.registration')
    );
  }
  
  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'custom_registration.trainingregistrationconfig',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'training_registration_config_edit_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, $id = NULL) {
    $config = $this->config('custom_registration.trainingregistrationconfig');
    $user_name = '';
    $email = '';
    $password = '';
    // checking and setting the data for edit.
    if(!empty($config->get('regidata'))){
      $regdata = unserialize($config->get('regidata'));
      if (array_key_exists($id, $regdata)) {
        $userData = $regdata[$id];
        $user_name = $userData['user_name'];
        $email = $userData['email'];
        $password = $userData['password'];
      }
      else{
        $this->messenger()->addMessage('Requested id does not exist in system.');
      }
    }
    
   // kint($userData); 
    $form['user_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('User Name'),
      '#maxlength' => 64,
      '#size' => 64,
      '#default_value' => $user_name,
    ];
    $form['email'] = [
      '#type' => 'email',
      '#title' => $this->t('Email'),
      '#default_value' => $email,
    ];
    $form['password'] = [
      '#type' => 'password',
      '#title' => $this->t('Password'),
      '#maxlength' => 64,
      '#size' => 64,
      '#default_value' => $password,
    ];
    $form['edit_id'] = [
      '#type' => 'hidden',
      '#default_value' => $id,
    ];
    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    parent::submitForm($form, $form_state);
    $id = $form_state->getValue('edit_id');
    $registrationData = [
      'user_name' => $form_state->getValue('user_name'),
      'email' => $form_state->getValue('email'),
      'password' => $form_state->getValue('password'),
    ];
    //kint($registrationData); 
    $response = $this->regConfig->editRegistrationConfigData($registrationData, $id);
    $this->messenger()->addMessage('Registration data updated successfully.');
  }
}
